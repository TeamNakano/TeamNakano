import fetch from 'node-fetch'

let handler = async (m, { conn, text }) => {
if (!text) return conn.reply(m.chat, '🚩 *Ingrese la url de la cancion de YouTube*', m)
try {
let app = await fetch(`https://apis-starlights-team.koyeb.app/starlight/transcribir-youtube?url=${text}`, { headers: { 'Content-Type': 'application/json' }})
let res = await app.json()
if (!res.result) throw m.reply('🚫 ///Error/// 🚫')
await conn.reply(m.chat, res.result, m)
} catch (error) {
}}
handler.help = ['transcripyt *<url>*']
handler.tags = ['tools']
handler.command = /^(transcripyt)$/i
export default handler
