## 💞 **`𝙽𝙰𝙺𝙰𝙽𝙾 - 𝙱𝙾𝚃 - 𝙾𝙵𝙲`**
## 💞 **`EL BOT MAS DIVERTIDO DE WHATSAPP`**
[![Typing SVG](https://readme-typing-svg.demolab.com?font=Fira+Code&pause=1000&color=FF0000&lines=Bienvenido+al+Repositorio;Nakano+-+Bot+-+OFC;Gracias+por+preferirnos;Creado+por+Lobo;💖+Sensei!!!;💞)](https://git.io/typing-svg)
![Nakano](https://telegra.ph/file/ba3bb9737d903a0994570.jpg)

```
- Descarga termux dando clic [aqui](https://f-droid.org/repo/com.termux_118.apk)

---------

## <img src="https://i.giphy.com/media/nWGRHBnAl5Kmc/giphy.gif" alt="Instalacion" width="40" height="40"> Instalación en [termux](https://f-droid.org/repo/com.termux_118.apk)

```bash
cd && termux-setup-storage
```

```bash
apt-get update -y && apt-get upgrade -y
```

```bash
pkg install -y git nodejs ffmpeg imagemagick && pkg install yarn 
```

```bash
git clone https://github.com/Team Koruda ofc/Koruda.git && cd Koruda-bot
```

```bash
yarn install
```

```bash
npm install
```

```bash
npm update
```

```bash
npm start
```

- Después de eso te aparecerά un código **QR** lo escaneas con el Whatsapp web y listo

---------

## <img src="https://i.pinimg.com/originals/73/69/6e/73696e022df7cd5cb3d999c6875361dd.gif" alt="Características" width="42" height="42"> Características

> Bot en creación pronto se agregaran más cosas 

- [x] Interacción con voz y texto
- [x] Configuración de grupo
- [x] antidelete, antilink, antiarabes, etc
- [x] Bienvenida personalizada
- [x] Imágenes a url
- [x] Juego RPG
- [ ] Otros

---------

## <img src="https://i.pinimg.com/originals/19/80/6e/19806e91932e6054965fc83b85241270.gif" alt="Contacto" width="42" height="42"> Contacto

- Si el Bot tiene algún contactame ฅ^•ﻌ•^ฅ

* <a href="https://wa.me/5493405480284"><img alt="WhatsApp" src="https://img.shields.io/badge/WhatsApp-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

---------

## <img src="https://static.wikia.nocookie.net/nyancat/images/d/d3/Nyan-cat.gif/revision/latest/scale-to-width-down/400?cb=20131231222500&path-prefix=es" alt="Grupo" width="45" height="43"> Grupo de WhatsApp


- Si quieres probar la Bot antes de instalar

* <a href="https://chat.whatsapp.com/GnZTHDnObwQ3aaq9szHSPP"><img alt="Group" src="https://img.shields.io/badge/Group-25D366?style=for-the-badge&logo=whatsapp&logoColor=white"/></a>

---------

## Repo Nakano

![github card](https://github-readme-stats.vercel.app/api/pin/?username=LOBO50K&repo=THE-QUINTUPLETS-&theme=chartreuse-dark)

---------

## <img src="https://raw.githubusercontent.com/vilcajoal/vilcajoal/master/assets/octocat-anime.gif" alt="Github" width="44" height="44"> Github Nakano

![github Nakano](https://github-readme-stats.vercel.app/api?username=LOBO50K&show_icons=true&theme=chartreuse-dark)
![github toplang](https://github-readme-stats.vercel.app/api/top-langs/?username=LOBO50K&layout=compact&theme=chartreuse-dark)

---------
<div align="center">
  <h1 align="center">Editor y Propietario de la Bot</h1>

<a href="https://github.com/LOBO50K"><img src="https://i.ibb.co/BGmBdgx/file.jpg" width="300" height="300" alt="Lobo💞"/></a>

` Nakano Bot / Team Nakano / Powered By:Lobo`
